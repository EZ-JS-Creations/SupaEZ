const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '..', 'dist', 'supaez.global.js'), 'utf8');

function createEnvironment() {
  const document = {
    currentScript: null,
    readyState: 'loading',
    head: { appendChild() {} },
    documentElement: { appendChild() {} },
    addEventListener() {},
    querySelector() { return null; },
    querySelectorAll() { return []; },
    dispatchEvent() { return true; }
  };
  let calls = 0;
  const client = {
    auth: { signInWithPassword() {} },
    from(table) { return { table }; }
  };
  const window = {
    document,
    URL,
    console,
    setTimeout,
    CustomEvent: class CustomEvent { constructor(type, options) { this.type = type; this.detail = options && options.detail; } },
    atob,
    supabase: {
      createClient(url, key, options) {
        calls += 1;
        return Object.assign({ url, key, options }, client);
      }
    }
  };
  vm.runInNewContext(source, { window, URL, console, setTimeout, atob });
  return { window, document, getCreateCalls: () => calls };
}

test('connect creates a Supabase client and exposes helpers', async () => {
  const env = createEnvironment();
  const client = await env.window.SupaEZ.connect({
    url: 'https://example-project.supabase.co',
    key: 'sb_publishable_test_key'
  });

  assert.equal(client.url, 'https://example-project.supabase.co');
  assert.equal(env.window.SupaEZ.client, client);
  assert.equal(env.window.SupaEZ.auth, client.auth);
  assert.equal(env.window.SupaEZ.from('tasks').table, 'tasks');
  assert.equal(env.getCreateCalls(), 1);
});

test('reuses a client for the same project and key', async () => {
  const env = createEnvironment();
  const config = { url: 'https://example-project.supabase.co', key: 'sb_publishable_test_key' };
  const first = await env.window.SupaEZ.connect(config);
  const second = await env.window.SupaEZ.connect(config);
  assert.equal(first, second);
  assert.equal(env.getCreateCalls(), 1);
});

test('rejects a secret key in browser config', async () => {
  const env = createEnvironment();
  await assert.rejects(
    env.window.SupaEZ.connect({ url: 'https://example-project.supabase.co', key: 'sb_secret_do_not_use' }),
    /secret\/service-role key/i
  );
  assert.equal(env.getCreateCalls(), 0);
});

test('rejects an invalid project URL', async () => {
  const env = createEnvironment();
  await assert.rejects(
    env.window.SupaEZ.connect({ url: 'not-a-url', key: 'sb_publishable_test_key' }),
    /not a valid URL/i
  );
});
